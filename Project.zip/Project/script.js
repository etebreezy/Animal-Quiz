// JavaScript Code
let oneVal = 0;
let twoVal = 0;
let threeVal = 0;
let fourVal = 0;
let fiveVal = 0;
let sixVal = 0;
let sevenVal = 0;
let eightVal = 0;
let nineVal = 0;
let tenVal = 0;

// Jquery Code
$(document).ready(() => {

    // Slider configuration
    const width = 765;
    const animateSpeed = 1000;
    const pause = 3000;

    let currentSlide = 1;
    let interval;
    const $slider = $('.section3-left-div');
    const $slideContainer = $slider.find('.slides');
    const $slides = $slideContainer.find('.slide');

    // Start slider functio
    function startSlider() {
        interval = setInterval(function() {
            $slideContainer.animate({'margin-left': '-='+width}, animateSpeed, function() {
                currentSlide++;
                if (currentSlide === $slides.length) {
                    currentSlide = 1;
                    $slideContainer.css('margin-left', 0);
                };
            });
        }, pause);
    };

    // Stop slider function
    function stopSlider() {
        clearInterval(interval);
    }

    // Stop and Start slider on mouse hover
    $slides.on('mouseenter', stopSlider).on('mouseleave', startSlider);

    startSlider();

    // Hide Questions when page loads
    $('.question-border-div').hide();
    $('.score-div').hide();

    // Show questions after get started is clicked
    $('#start-form').on('submit', function(eventOne) {
        eventOne.preventDefault();

        const firstName = $('#first-name').val().trim();
        const lastName = $('#last-name').val().trim();
       
        if (firstName !== '' && lastName !== '') {
            $('.candidate-name').append(`${firstName} ${lastName}`);
            $('#first-name').val('');
            $('#last-name').val('');
        }
        
        $('.border-div').slideUp(1000);
        $('.question-border-div').show();
    });

    // Show scores once we click the submit button
    $('#submit-form').on('submit', function(eventTwo) {
        eventTwo.preventDefault();
        
        // Get Values from the questions radio button
        const questionOneVal = document.querySelector('input[name="answer-one"]:checked').value;
        const questionTwoVal = document.querySelector('input[name="answer-two"]:checked').value;
        const questionThreeVal = document.querySelector('input[name="answer-three"]:checked').value;
        const questionFourVal = document.querySelector('input[name="answer-four"]:checked').value;
        const questionFiveVal = document.querySelector('input[name="answer-five"]:checked').value;
        const questionSixVal = document.querySelector('input[name="answer-six"]:checked').value;
        const questionSevenVal = document.querySelector('input[name="answer-seven"]:checked').value;
        const questionEightVal = document.querySelector('input[name="answer-eight"]:checked').value;
        const questionNineVal = document.querySelector('input[name="answer-nine"]:checked').value;
        const questionTenVal = document.querySelector('input[name="answer-ten"]:checked').value;

        
        // Score calculation
        
        if (questionOneVal =='tiger') {
            oneVal = 1;
        } 

        if (questionTwoVal == '22 months') {
            twoVal = 1;
        } 

        if (questionThreeVal == 'bison') {
            threeVal = 1;
        } 

        if (questionFourVal == 'snake') {
            fourVal = 1;
        } 

        if (questionFiveVal == 'goat') {
            fiveVal = 1;
        } 

        if (questionSixVal == 'sloth') {
            sixVal = 1;
        } 

        if (questionSevenVal == 'polar bear') {
            sevenVal = 1;
        } 

        if (questionEightVal == 'lion') {
            eightVal = 1;
        } 

        if (questionNineVal == 'gorilla') {
            nineVal = 1;
        } 

        if (questionTenVal ==='bat') {
            tenVal = 1;
        } 

        const getScore = (oneVal + twoVal + threeVal + fourVal + fiveVal + sixVal + sevenVal + eightVal + nineVal + tenVal);

        $('.candidate-score').append(`You scored: ${getScore} / 10`);

        if (getScore > 5) {
            $('.score-div h1').append(`You Passed!!!`); 
        } else {
            $('.score-div h1').append(`You Failed!!!`); 
            $('.try-again').append(`Click to Try Again`);
        }

        $('.question-slideup').hide();
        
        $('.score-div').show();
 
    });

});